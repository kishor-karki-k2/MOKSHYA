package com.example.kishor;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
